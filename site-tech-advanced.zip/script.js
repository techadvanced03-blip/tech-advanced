// Small client-side enhancement
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('commandeForm');
  if(form){
    form.addEventListener('submit', function(){
      // basic feedback
      alert('Merci ! Votre commande a été envoyée. Vérifie ta boîte email.');
    });
  }
});
