# Tech Advanced - Site de commandes (GitHub Pages)

Site statique prêt à être hébergé sur GitHub Pages.

## Contenu
- Pages: index.html, produits.html, commande.html, contact.html
- Formulaires: Utilisent FormSubmit.co pour envoyer les commandes à **talebakram19@gmail.com**
  - La première soumission demandera de confirmer l'activation depuis l'email.

## Déploiement rapide
1. Crée un nouveau repository sur GitHub (public).
2. Téléverse (drag & drop) tous les fichiers du dossier `site-tech-advanced`.
3. Dans **Settings > Pages**, choisis la branche `main` (ou `gh-pages`) et le dossier `/ (root)`.
4. Attends quelques minutes, ton site sera disponible sur:
   `https://<tonpseudo>.github.io/<nom-du-repo>/`

## Notes
- Les images dans `img/` sont des placeholders. Remplace-les par tes photos.
- Pour personnaliser le style, édite `style.css`.
